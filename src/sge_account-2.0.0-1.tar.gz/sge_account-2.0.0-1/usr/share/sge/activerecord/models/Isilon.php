<?php
	class Isilon extends ActiveRecord\Model {
		static $table_name = 'isilon'; // Por defecto espera que las tablas sean en plural, esta es en singular
	}
?>
