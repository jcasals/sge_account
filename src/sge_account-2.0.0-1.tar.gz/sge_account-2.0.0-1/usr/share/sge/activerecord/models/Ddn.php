<?php
	class DDN extends ActiveRecord\Model {
		static $table_name = 'ddn'; // Por defecto espera que las tablas sean en plural, esta es en singular
	}
?>
