<?php
	$path=(dirname(__FILE__));
	echo" 
	<meta charset=\"utf-8\">
	<title>SGE Accounting</title>
	<meta name=\"description\" content=\"\">
	<meta name=\"author\" content=\"Jordi Casals, Arnau Bria\">
	
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
	<meta http-equiv=\"Content-Script-Type\" content=\"text/javascript\">
	<meta http-equiv=\"Content-Language\" content=\"en-us\" />
	
	<!-- STYLE -->
	<link rel=\"stylesheet\" type=\"text/css\" href=\"css/bootstrap.min.css\">
	<link rel=\"stylesheet\" type=\"text/css\" href=\"css/bootstrap.datatables.css\">
	<link rel=\"stylesheet\" type=\"text/css\" href=\"css/jquery-ui.css\"> <!-- 1.8.16 -->
	<link rel=\"stylesheet\" type=\"text/css\" href=\"css/css.css\">
	
	<!-- JAVASCRIPT -->
	<script type=\"text/javascript\" src=\"js/jquery.js\"></script>
	<script type=\"text/javascript\" src=\"js/jquery-ui.js\"></script> <!-- 1.8.16 -->
	<script type=\"text/javascript\" src=\"js/jquery.validate.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/bootstrap.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/jquery.dataTables.min.js\"></script>
	<script type=\"text/javascript\" src=\"js/bootstrap.datatables.js\"></script>
	<script type=\"text/javascript\" src=\"js/raphaeljs/raphael.js\"></script>
	<script type=\"text/javascript\" src=\"js/raphaeljs/g.raphael.js\"></script>
	<script type=\"text/javascript\" src=\"js/raphaeljs/g.pie.js\"></script>
	<script type=\"text/javascript\" src=\"js/plot.js\"></script>
	<script type=\"text/javascript\" src=\"js/js.js\"></script>
	
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	<script src=\"http://html5shim.googlecode.com/svn/trunk/html5.js\"></script>
	<![endif]-->
	
	<!-- Le fav and touch icons -->
	<link rel=\"shortcut icon\" href=\"images/favicon.ico\" type=\"image/x-icon\" />";
?>
