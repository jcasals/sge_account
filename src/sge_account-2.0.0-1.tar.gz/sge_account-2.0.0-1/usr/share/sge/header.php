<div class="navbar navbar-fixed-top navbar-inverse">
	<div class="navbar-inner">
		<a class="brand" href="http://accounting.linux.crg.es/index.php">Hub</a>
		<ul class="nav">
			<li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown">Accounting <b class="caret"></b></a>
				<ul class="dropdown-menu">
					<li><a href="http://accounting.linux.crg.es/sge.php">SGE</a></li>
					<li><a href="http://accounting.linux.crg.es/addons/sge_billing/sge_billing.php">Billing</a></li>
					<li><a href="http://accounting.linux.crg.es/addons/sge_efficiency/sge_eff.php">Efficiency</a></li>
				</ul>
			</li>                   
			<?php
				$path=(dirname(__FILE__));
				foreach (glob("$path/addons/head_addons/*.php") as $filename){
					include_once $filename;
				}
			?>
		</ul>
	</div>
</div>
